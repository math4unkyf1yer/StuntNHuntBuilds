# Stunting n Hunting

## CONTROLS


| Control (KBM)  | Action |
| -------------| ------------- |
| AD  | Move  |
| S  | Slow Down  |
| Hold Space | Backflip|
| Hold Right Click | Change Camera|
| Left Click | Shooting|

## RELEASE NOTES/BUGS
+ First Person Cam works but needs further adjustments with recentering
+ Enemy AI is still in progress. At the moment only one enemy type is functional, but no hitbox
+ Collision with wall causes gameover, but will respawn at a soft lock position
+ Ramp needs improvement
